#include <stdio.h>
#include <stdlib.h>

void afficherAide() {
    printf("\n===== Aide du Jeu : Quoridor =====\n");
    printf("Objectif du jeu :\n");
    printf("Le but est d'atteindre le bord opposé à sa ligne de départ avant les autres joueurs.\n\n");

    printf("Participants :\n");
    printf(" - 2 ou 4 joueurs.\n");
    printf(" - Chaque joueur place son pion sur le plateau et reçoit un certain nombre de barrières.\n\n");

    printf("Déroulement du jeu :\n");
    printf("1. Les joueurs jouent chacun à leur tour.\n");
    printf("2. À chaque tour, un joueur peut soit déplacer son pion, soit placer une barrière pour bloquer les adversaires.\n");
    printf("3. Les pions peuvent se déplacer d'une case à la fois, verticalement ou horizontalement, mais pas en diagonale.\n\n");

    printf("Placement des barrières :\n");
    printf(" - Les barrières sont placées entre deux cases et doivent bloquer le chemin d'un adversaire sans pour autant lui interdire\n");
    printf("   totalement l'accès au bord opposé.\n\n");

    printf("Conditions de victoire :\n");
    printf(" - Le premier joueur à atteindre le bord opposé de sa ligne de départ gagne la partie.\n\n");

    printf("====================================\n\n");
}

void afficherScores() {
    printf("\n===== Scores des Joueurs =====\n");
    printf("Les scores seront affichés ici (fonctionnalité en cours de développement).\n\n");
}

void afficherMenu() {
    printf("===== Menu Principal =====\n");
    printf("1. Lancer une nouvelle partie\n");
    printf("2. Reprendre une partie sauvegardée\n");
    printf("3. Afficher l’aide\n");
    printf("4. Afficher les scores des joueurs\n");
    printf("5. Quitter le jeu\n");
    printf("Veuillez choisir une option : ");
}

int main() {
    int choix;
    int quitter = 0;

    while (!quitter) {
        afficherMenu();
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                printf("Lancer une nouvelle partie...\n");
                // Code pour lancer une nouvelle partie
                break;
            case 2:
                printf("Reprendre une partie sauvegardée...\n");
                // Code pour reprendre une partie sauvegardée
                break;
            case 3:
                afficherAide();
                break;
            case 4:
                afficherScores();
                break;
            case 5:
                printf("Au revoir !\n");
                quitter = 1;
                break;
            default:
                printf("Option invalide. Veuillez choisir une option entre 1 et 5.\n");
        }
    }

    return 0;
}
